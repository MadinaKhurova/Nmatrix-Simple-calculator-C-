using Nmatrix;
using System.ComponentModel;
using static Nmatrix.Nmat;

namespace NmatTest.cs
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Default()
        {
            Nmat matrix = new Nmat();
            Assert.AreEqual(3, matrix.Size);
            Assert.AreEqual("1 0 2 \n3 4 5 \n6 0 7 \n", matrix.ToString());

        

        }
        [TestMethod]
        public void Constractor()
        {
            //initialization
            List<int> vec = new List<int> { 11, 22, 32, 41};
            Nmat matrix = new Nmat(vec);
            Assert.AreEqual(2, matrix.Size);
            Assert.AreEqual("11 22 \n32 41 \n", matrix.ToString());
            //copy
            List<int> vec1 = new List<int> { 1, 2, 3, 4, 5, 6 };
            Nmat matrix1 = new Nmat(vec1);
            Nmat matrix2 = new Nmat(matrix1);
            Assert.AreEqual(matrix1.ToString(), matrix2.ToString());

        }
        [TestMethod]
        public void Index()
        {
            Nmat matrix = new Nmat(2);
            matrix[0, 0] = 9;
            Assert.AreEqual(9, matrix[0, 0]);
            Assert.ThrowsException<IndexOutOfRangeException>(() => matrix[3, 3] = 1);


        }
        [TestMethod]
        public void Addition()
        {
            Nmat matrix1 = new Nmat(new List<int> { 1, 2, 3, 4, 5, 6, 7 });
            Nmat matrix2 = new Nmat(new List<int> { 6, 5, 4, 3, 2, 1, 0 });
            Nmat result = Nmat.Add(matrix1, matrix2);
            Assert.AreEqual("7 0 7 \n7 7 7 \n7 0 7 \n", result.ToString());
            Assert.ThrowsException<DifferentSizeException>(() => Nmat.Add(new Nmat(2), new Nmat(3)));


        }


        [TestMethod]
        public void Multiplication()
        {
            Nmat matrix1 = new Nmat(new List<int> { 1, 2, 3, 4, 5, 6, 7 });
            Nmat matrix2 = new Nmat(new List<int> { 7, 6, 5, 42, 3, 4, 5 });
            Nmat result = Nmat.Multiply(matrix1, matrix2);
            Assert.AreEqual("15 0 16 \n61 168 55 \n70 0 71 \n", result.ToString());
            Assert.ThrowsException<DifferentSizeException>(() => Nmat.Multiply(new Nmat(2), new Nmat(3)));

        }




    }
}