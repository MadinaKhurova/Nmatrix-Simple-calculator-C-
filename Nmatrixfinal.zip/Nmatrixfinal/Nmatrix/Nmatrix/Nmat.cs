﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Linq.Expressions;
using System.Threading.Tasks;
using TextFile;



namespace Nmatrix
{
    public class Nmat
    {
        public class NegativeSizeException : Exception { };
        public class OutOfNmatrixException : Exception { };
        public class DifferentSizeException : Exception { };
        public class InvalidVectorException : Exception { };
        public class ReferenceToNullPartException : Exception { };

        private List<int> _vec;
        private int _size;

        private int ind(int i, int j)
        {
            if (i == 0)
            {
                if (_size != 1)
                    return j / (_size - 1);
                else
                    return j;

            }
            else
            {
                if (j == 0)
                    return 1 + 3 * (i - 1) + 1;
                else if (j == i)
                    return 1 + 3 * (i - 1) + 2;
                else if (j == _size - 1)
                    return 1 + 3 * (i - 1) + 3;
                else return -1;
            }

        }
        private double calcSizeFromLength(int size)
        {
            return (size + 2) / 3;
        }
        private bool inNmat(int i, int j)
        {
            return j == 0 || j == i || j == _size - 1 && i >= 0 && i < _size;

        }
        public Nmat()
        {
            _size = 3;
            _vec = new List<int>() { 1, 2, 3, 4, 5, 6, 7 };
        }
        public Nmat(in List<int> vec)
        {
            SetVec(vec);
        }
        public Nmat(int size)
        {
            if (size <= 0) throw new NegativeSizeException();

            _size = size;
            _vec = new List<int>();
            int length = size * 3 - 2;


            for (int i = 0; i < length; ++i)
            {
                _vec.Add(0);
            }
        }

        public Nmat(in Nmat m)
        {
            _size = m._size;
            _vec = m._vec;

        }



        public int Size
        {
            get { return _size; }
        }

        public int this[int i, int j]
        {
            get
            {
                if (i < 0 || i >= Size || j < 0 || j >= Size) throw new IndexOutOfRangeException();
                if (inNmat(i, j)) return _vec[ind(i, j)];
                else return 0;
            }
            set
            {
                if (i < 0 || i >= Size || j < 0 || j >= Size) throw new IndexOutOfRangeException();
                if (inNmat(i, j)) _vec[ind(i, j)] = value;
            }
        }
        public int GetElement(int i, int j)
        {
            if (i < 0 || i >= _size || j < 0 || j >= _size) throw new IndexOutOfRangeException();
            if (inNmat(i, j)) return _vec[ind(i, j)];
            else return 0;

        }
        void SetElement(int i, int j, int e)
        {
            if (i < 0 || i >= _size || j < 0 || j >= _size) throw new IndexOutOfRangeException();
            if (inNmat(i, j)) _vec[ind(i, j)] = e;
            else throw new OutOfNmatrixException();

        }





        public override string ToString()
        {
            string str = "";
            for (int i = 1; i <= _size; i++)
            {
                for (int j = 1; j <= _size; j++)
                {
                    str += GetElement(i - 1, j - 1).ToString() + " ";
                }
                str += "\n";
            }
            return str;
        }

        public void SetVec(List<int> vec)
        {

            double n = calcSizeFromLength(vec.Count);
            if (n == Math.Floor(n))
            {
                _size = Convert.ToInt32(n);
                _vec = vec;
            }
            else /// invalid vector length
            {
                throw new InvalidVectorException();
            }
        }





        public static Nmat Add(Nmat a, Nmat b)
        {
            if (a.Size != b.Size) throw new DifferentSizeException();
            Nmat sum = new Nmat(a);
            for (int i = 0; i < a._vec.Count; i++)
            {
                a._vec[i] = a._vec[i] + b._vec[i];

            }
            return sum;
        }

        public static Nmat Multiply(Nmat a, Nmat b)
        {
            if (a.Size != b.Size) throw new DifferentSizeException();

            Nmat mul = new Nmat(a.Size);
            for (int i = 0; i < a._size; i++)
            {
                for (int j = 0; j < a._size; j++)
                {
                    if (a.inNmat(i, j)) 
                    {
                        for (int k = 1; k <= a._size; k++)
                        {
                            mul.SetElement(i, j, mul.GetElement(i, j) + a.GetElement(i, k - 1) * b.GetElement(k - 1, j));
                        }
                    }

                }
            }

            return mul;

        }
    }
}