﻿
using System.Globalization;
using System.Threading;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;

namespace Nmatrix
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Menu m = new();
            m.Run();
            
        }
          
    }
}